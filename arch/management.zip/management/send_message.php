<?php
ob_start();
session_start();

require("../includes/host.php");
require("../includes/kc_connection.php");
require("../includes/common-functions.php");
require("../includes/checkAuth.php");
require("../includes/sendMail.php");
require("../includes/sendMessage.php");

if(!userCan($conn,$_SESSION['login_id'],$privilegeName = 'manage_send_message')){
  header("location:/kanoujia/index.php");
  exit();
}

$url = $pagination_url = 'send_message.php';
$url .= '?search=true';
$pagination_url .= '?';

$limit = 200;
if(isset($_GET['page'])){
    $page = $_GET['page'];
    $url .= '&page='.$_GET['page'];
}else{
    $page = 1;
}
$query = "select * from kc_contacts where status = '1' ";

$allBtnText = 'Send To All';
if(isset($_GET['type']) && in_array($_GET['type'],array('contacts','customers','employees','associate'))){
  $url .= "&type=".$_GET['type'];
  
  if(isset($_GET['type']) && $_GET['type'] == "contacts"){
    $query .= " and type = 'Contact'";
    $pagination_url .= "type=".$_GET['type']."&";
    $allBtnText = 'Send To All Contacts';
  }else if(isset($_GET['type']) && $_GET['type'] == "customers"){
    $query .= " and type = 'Customer'";
    $pagination_url .= "type=".$_GET['type']."&";
    $allBtnText = 'Send To All Customers';
  }else if(isset($_GET['type']) && $_GET['type'] == "employees"){
    $query .= " and type = 'Employee'";
    $pagination_url .= "type=".$_GET['type']."&";
    $allBtnText = 'Send To All Employees';
  }else if(isset($_GET['type']) && $_GET['type'] == "associate"){
    $query .= " and type = 'Associate'";
    $pagination_url .= "type=".$_GET['type']."&";
    $allBtnText = 'Send To All Associates';
  }
}

if(isset($_POST['sendToAll']) && $_POST['sendToAll'] == "Send To All" && isset($_POST['template']) ){
  $contacts = mysqli_query($conn,$query);
  $message_count = 0;
  if(mysqli_num_rows($contacts) > 0){
    while($contact = mysqli_fetch_assoc($contacts)){
      if(strlen($contact['mobile']) == 10){
        //$message
        $variables_array = array_filter($_POST['variables']);
        $variables_array['variable1'] = $contact['name'];
            //echo "<pre>"; print_r($variables_array); die;
        if(sendMessage($conn,$_POST['template'],$contact['mobile'],$variables_array)){
          $message_count++;
        }
      }
    }
  }
  if($message_count > 0){
    $_SESSION['success'] = $message_count.' messages sent successfully.';
  }else{
    $_SESSION['error'] = 'No messages sent.';
  }
  header("location:$url");
  exit();
}

if(isset($_POST['send']) && $_POST['send'] == "Send" && isset($_POST['template']) && isset($_POST['contacts']) && is_array($_POST['contacts']) && sizeof($_POST['contacts']) > 0 && is_array($_POST['names']) && sizeof($_POST['contacts']) <= sizeof($_POST['names'])){
	
	$message_count = 0;

  $combine = false;
  if(in_array($_POST['template'],templatesWithoutVariable())){
    $combine = true;
  }
  
  if($combine){
    // echo "<pre>"; echo $_POST['template']; print_r($_POST['contacts']); die;
    $mobile_nos = implode(',',$_POST['contacts']);
    sendWishes($conn,$_POST['template'],$mobile_nos);
    $message_count = sizeof($_POST['contacts']);
  }else{
    echo "heres"; die;
    foreach($_POST['contacts'] as $key => $mobile_no){
      if(isset($_POST['names'][$key]) && strlen($mobile_no) == 10){
        //$message
        $variables_array = array_filter($_POST['variables']);
        $variables_array['variable1'] = $_POST['names'][$key];
            //echo "<pre>"; print_r($variables_array); die;
        if(sendMessage($conn,$_POST['template'],$mobile_no,$variables_array)){
          $message_count++;
        }
      }
    }
  }

 

	

	if($message_count > 0){
		$_SESSION['success'] = $message_count.' messages sent successfully.';
	}else{
		$_SESSION['error'] = 'No messages sent.';
	}
	header("location:$url");
	exit();
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Kanoujia City | Admin Panel</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <link href="/<?php echo $host_name; ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
    <link href="/<?php echo $host_name; ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="/<?php echo $host_name; ?>/css/ionicons.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Select2 -->
    <link href="/<?php echo $host_name; ?>/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
	
    <!-- Theme style -->
    <link href="/<?php echo $host_name; ?>/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="/<?php echo $host_name; ?>/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="/<?php echo $host_name; ?>/plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="/<?php echo $host_name; ?>/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="/<?php echo $host_name; ?>/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="/<?php echo $host_name; ?>/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="/<?php echo $host_name; ?>/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="/<?php echo $host_name; ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Developer Css -->
    <link href="/<?php echo $host_name; ?>/css/style.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/<?php echo $host_name; ?>/js/html5shiv.min.js"></script>
        <script src="/<?php echo $host_name; ?>/js/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
      .btn-app{
        color: white;
        border: none;
      }
    </style>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php require('../includes/header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php echo require('../includes/left_sidebar.php'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Masters
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Send Message</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
			<div class="box">
        <div class="box-header">
					<?php 
					include("../includes/notification.php"); ?>
					<div class="col-sm-4">
						<h3 class="box-title">Send Message</h3>
					</div>
          <div class="col-sm-8">
              <div class="col-sm-2">
                <a href="send_message.php" class="btn btn-app btn-primary" style="background-color: #3c8dbc;">
                  <i class="fa fa-bars"></i> All
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=associate" class="btn btn-app btn-info" style="background-color: #00c0ef;">
                  <i class="fa fa-tree"></i> Associate
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=contacts" class="btn btn-app btn-danger" style="background-color: #d73925;">
                  <i class="fa fa-bookmark"></i> Contacts
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=customers" class="btn btn-app btn-success" style="background-color: #00a65a;">
                  <i class="fa fa-users"></i> Customers
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=employees" class="btn btn-app btn-warning" style="background-color: #f0ad4e;">
                  <i class="fa fa-user"></i> Employees
                </a>
              </div>
          </div>
        </div><!-- /.box-header -->
        <div class="box-body no-padding">
        	<form enctype="multipart/form-data" action="<?php echo $url; ?>" name="send_message_frm" id="send_message_frm" method="post" class="form-horizontal dropzone">
                 <div class="col-sm-12">
                    <div class="form-group">
                      <label for="excel_file" class="col-sm-3 control-label">Select Template</label>
                      <div class="col-sm-8">
                        <select class="form-control" id="template" name="template" required>
                            <option value="">Select Template</option>
                            <optgroup label="Wishes">
                              <?php /*<option value="1">Dear VAR1, Happy VAR2 from Team Kanoujia City.</option>*/ ?>
                              <option value="2">May the light that we celebrate at Diwali show us the way and lead us together on the path of social peace and harmony.Happy Diwali Team Kanoujia City</option>

                              <option value="11">कनौजिया सिटी परिवार की ओर से झिलमिलाते दीपों की रोशनी से प्रकाशित ये दीपावली आपके घर में सुख समृद्धि और आशीर्वाद ले कर आये| शुभ दीपावली !कनौजिया सिटी रियल एस्टेट प्र0 लि0</option>
                              <option value="12">रोशनी और ख़ुशी के इस पावन पर्व पर आपकी सारी मनोकामनाएं पूरी हो और घर में सुख सम्पन्नता बरसे| शुभ धनतेरस! कनौजिया सिटी रियल एस्टेट प्र0 लि0</option>
                              <option value="13">May this Dhanteras Festival Wishing you with happiness, Wealth & Prosperity. Happy Dhanteras Kanoujia City Real Estate Pvt. Ltd.</option>
                              <option value="14">झिलमिलाते दीपों की रोशनी से प्रकाशित ये दीपावली आपके घर में सुख समृद्धि ले कर आये| शुभ दीपावली! कनौजिया सिटी रियल एस्टेट प्र0 लि0</option>
                              <option value="15">Have a wonderful year filled with peace, prosperity and happiness. Happy Diwali Kanoujia City Real Estate Pvt. Ltd.</option>

                              <option value="16">Kanoujia City wishing You and your family a very Happy New Year with a bright future.Team Kanoujia City</option>
                              <option value="17">Wishing you all a very Happy Republic Day! Freedom in the mind, strength in the words, pureness in our blood and pride in our souls. Let's salute our martyrs on Republic Day Team Kanoujia City</option>
                              <option value="18">आप को और आपके पूरे परिवार को होली की हार्दिक शुभकामनाएँ
टीम कनौजिया सिटी / अभिनंदन रिसॉर्ट</option>
                              <option value="20">आप को और आपके पूरे परिवार को राखी की हार्दिक शुभकामनाएँ टीम कनौजिया सिटी / अभिनंदन रिसॉर्ट</option>
                              <option value="21">आप सभी को स्वतंत्रता दिवस की हार्दिक शुभकामनाएँ। टीम कनौजिया सिटी / अभिनंदन रिजॉर्ट</option>
                              <option value="22">आप को और आपके पूरे परिवार को दशहरा की हार्दिक शुभकामनाएँ टीम कनौजिया सिटी / अभिनंदन रिसॉर्ट</option>
                              <option value="23">आप सभी को विजय दशमी दशहरा की हार्दिक शुभकामनाएँ टीम कनौजिया सिटी</option
                              >
                              <option value="25">धनतेरस के इस पावन पर्व पर आप सभी की सारी मनोकामनाएँ पूरी हो | शुभ धनतेरस कनौजिया सिटी रियल एस्टेट प्र0 लि0</option>
                              <option value="26">आप सभी को नववर्ष की हार्दिक शुभकामनाएँ टीम कनौजिया सिटी</option>
                              <?php /*<option value="3">Best wishes for joy and love this Christmas season, for you and your family.Merry Christmas Team Kanoujia City</option>
                              <option value="4">Kanoujia City wishes you & your family a very blissful, cheerful, colorful New Year with a smile. Best Regards, Team Kanoujia City</option>
                              <option value="5">Kites flying high to touch the happiness, Til mangled with sweet to spread sweetness. Wish you a very Happy Makar Sankranti Team Kanoujia City</option>
                              <option value="6">May this holi happiness overflow & there be lots of fun and frolic.Happy holi Best Regard, Team Kanoujia City</option>*/ ?>
                            </optgroup>
                            <optgroup label="Transactional">
                              <option value="7">Hi VAR1 Thank you for choosing us. We're happy to have you! Plot No.: VAR2 - VAR3 in VAR4 has been marked as booked by you Kanoujia City Real Estate Pvt. Ltd.</option>

                              <option value="8">Dear VAR1 We have received Rs. VAR2 against plot no. VAR3 - VAR4 as booking confirmation amount on VAR5.Kindly note cheque is subject to clearance.Kanoujia City Real Estate Pvt. Ltd.</option>

                              
                              <option value="9">Dear VAR1 We have received Rs. VAR2 as installment against plot no. VAR3 - VAR4 on VAR5.Kindly note cheque is subject to clearance.Kanoujia City Real Estate Pvt. Ltd.</option>
                            </optgroup>
                            <?php /*
                            <optgroup label="Miscellaneous">
                              <option value="10">Dear VAR1,  VAR2 Best Regards, Team Kanoujia City</option>
                            </optgroup>*/ ?>
                          </select>
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable2" style="display:none;">
                    <div class="form-group">
                      <label for="variable2" class="col-sm-3 control-label">VAR2</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable2" name="variables[variable2]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable3" style="display:none;">
                    <div class="form-group">
                      <label for="variable3" class="col-sm-3 control-label">VAR3</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable3" name="variables[variable3]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable4" style="display:none;">
                    <div class="form-group">
                      <label for="variable4" class="col-sm-3 control-label">VAR4</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable4" name="variables[variable4]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable5" style="display:none;">
                    <div class="form-group">
                      <label for="variable5" class="col-sm-3 control-label">VAR5</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable5" name="variables[variable5]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable6" style="display:none;">
                    <div class="form-group">
                      <label for="variable6" class="col-sm-3 control-label">VAR6</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable6" name="variables[variable6]">
                      </div>
                    </div>
                 </div>
                 <table class="table table-striped table-hover table-bordered">
                    <tr>
                      <th><input type="checkbox" id="checkAll" class="checkAll" for="checkAll"></th>
                      <th>Sl No.</th>
                      <th>Name</th>
                      <th>Mobile</th>
                      <th>Type</th>
                      <th>Created</th>
                    </tr>
                    <?php
                    $total_records = mysqli_num_rows(mysqli_query($conn,$query));
                    $total_pages = ceil($total_records/$limit);
                    
                    if($page == 1){
                        $start = 0;
                    }else{
                        $start = ($page-1)*$limit;
                    }
                    
                    $query .= " limit $start,$limit";

                    $contacts = mysqli_query($conn,$query);
                    if(mysqli_num_rows($contacts) > 0){
                        $counter = $start+1;
                        while($contact = mysqli_fetch_assoc($contacts)){ ?>
                            <tr>
                                <td><input type="checkbox" name="contacts[<?php echo $contact['id']; ?>]" value="<?php echo $contact['mobile']; ?>" class="contact"></td>
                                <td><?php echo $counter; ?>.</td>
                                <td><?php echo $contact['name']; ?><input type="hidden" name="names[<?php echo $contact['id']; ?>]" value="<?php echo $contact['name']; ?>"></td>
                                <td><?php echo $contact['mobile']; ?></td>
                                <td>
                                  <?php if($contact['type'] == "Associate"){ ?>
                                    <label class="label label-info">Associate</label>
                                  <?php }else if($contact['type'] == "Customer"){ ?>
                                    <label class="label label-success">Customer</label>
                                  <?php }else if($contact['type'] == "Contact"){ ?>
                                      <label class="label label-danger">Contact</label>
                                  <?php }else { ?>
                                      <label class="label label-warning">Employee</label>
                                  <?php } ?>
                                </td>
                                <td><?php echo date("d M Y h:i A",strtotime($contact['created'])); ?></td>
                                
                            </tr>
                            <?php
                            $counter++;
                        } ?>
                        <tr>
                            <td colspan="6" align="center">

                              <?php /*<button id="sendToAll" class="btn btn-sm btn-primary" name="sendToAll" onclick="return validateAll();" value="Send To All"><?php echo $allBtnText; ?></button>*/ ?>
                              <button id="send" type="submit" name="send" class="btn btn-primary btn-sm" onclick="return validate();" value="Send">Send To Selected</button>
                            </td>
                        </tr>
                        <?php
                    }else{
                        ?>
                        <tr>
                            <td colspan="9" align="center"><h4 class="text-red">No Record Found</h4></td>
                        </tr>
                        <?php
                    }
                    ?>
                  </table>
              </form>
        </div><!-- /.box-body -->
				
				<?php if($total_pages > 1){ ?>
					<div class="box-footer clearfix">
					  <ul class="pagination pagination-sm no-margin pull-right">
					   
						<?php

            
							for($i = 1; $i <= $total_pages; $i++){
								?>
								 <li <?php if((isset($_GET['page']) && $i == $_GET['page']) || (!isset($_GET['page']) && $i == 1)){ ?>class="active"<?php } ?>><a href="<?php echo $pagination_url ?>page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php
							}
						?>
						
					  </ul>
					</div>
				<?php } ?>
				
              </div><!-- /.box -->
        </section> 
          
      </div><!-- /.content-wrapper -->    
      <?php require('../includes/footer.php'); ?>
    </div><!-- ./wrapper -->
	
	<?php require('../includes/common-js.php'); ?>
	
    <script type="text/javascript">
	$(function(){
		$("#template").change(function(){
			if($(this).val() == '8' || $(this).val() == '9'){
				$(".variable5").show();
			}else{
				$(".variable5").hide();
			}

			if($(this).val() == '7' || $(this).val() == '8' || $(this).val() == '9'){
				$(".variable4").show();
			}else{
				$(".variable4").hide();
			}

			if($(this).val() == '7' || $(this).val() == '8' || $(this).val() == '9'){
				$(".variable3").show();
			}else{
				$(".variable3").hide();
			}

			if($(this).val() == '7' || $(this).val() == '8' || $(this).val() == '9'){
				$(".variable2").show();
			}else{
				$(".variable2").hide();
			}

			<?php /*else if($(this).val() == '1' || $(this).val() == '5'){
				$(".variable2").show();
			}else{
				$(".variable2").find('input').val('');
				$(".variable2").hide();
			}*/ ?>
		});
    /*$("#send_message_frm").submit(function(e){

      if($("#template").val() == ""){
        alert("Please select a Message Template.");
        e.preventDefault();
      }else if($("#template").val() == "1" && $("#variable2").val() == ""){
        alert("Please Fill Festival Name.");
        e.preventDefault();
      }else if($(".contact:checked").length == 0){
        alert("Please select atleast one Contact.");
        e.preventDefault();
      }
    });*/
	});
  function validate(){
    if($("#template").val() == ""){
      alert("Please select a Message Template.");
      return false;
    }else if($("#template").val() == "1" && $("#variable2").val() == ""){
      alert("Please Fill Festival Name.");
      return false;
    }else if($(".contact:checked").length == 0){
      alert("Please select atleast one Contact.");
      return false;
    }

    var error = false;
    $(".variable2,.variable3,.variable4,.variable5,.variable6").each(function(){
      if($(this).css('display') != "none" && $(this).find('input').val() == ""){
        error = true;
      }
    });
    if(error){
      alert("Please Fill all variable field");
      return false;
    }
  }

  function validateAll(){
    
    if($("#template").val() == ""){
      alert("Please select a Message Template.");
      return false;
    }
    var error = false;
    $(".variable2,.variable3,.variable4,.variable5,.variable6").each(function(){
      if($(this).css('display') != "none"){
        error = true;
      }
    });
    if(error){
      alert("This Message Template is not allowed for <?php echo $allBtnText; ?>");
      return false;
    }
    if(!confirm('Are you sure you want this message <?php echo $allBtnText; ?>')){
      return false;
    }
  }
	function iCheckClicked(elem){
		 var for_attr = $(elem).attr('for');
		 if(for_attr == "checkAll"){
			 if(!($(elem).is(":checked"))){
			 	$('.contact').iCheck('check');
			 }else{
				 $('.contact').iCheck('uncheck');
			 }
		 }
	}
	</script>
    
  </body>
</html>