<?php
	ob_start();
	session_start();

	require("../includes/host.php");
	require("../includes/kc_connection.php");
	require("../includes/common-functions.php");
	require("../includes/checkAuth.php");

	header("Content-Type: application/xls");    
	header("Content-Disposition: attachment; filename=report-".date('d-M-y').".xls");  
	header("Pragma: no-cache"); 
	header("Expires: 0");

	$query = "select cth.id as customer_block_id,cth.id, cth.customer_id,cth.cancel_remarks,cth.action_type, cth.bank_name,cth.remarks, cth.cheque_dd_number, cth.amount, cth.paid_date, cth.block_id, cth.block_number_id,cth.remarks, b.project_id, b.name as block_name, bn.block_number as block_number_name, bn.area, p.name as project_name, c.name_title as customer_name_title, c.name as customer_name, c.mobile as customer_mobile, c.address as customer_address from kc_customer_transactions_hist cth LEFT JOIN kc_blocks b ON cth.block_id = b.id LEFT JOIN kc_block_numbers bn ON cth.block_number_id = bn.id LEFT JOIN kc_projects p ON b.project_id = p.id LEFT JOIN kc_customers c ON cth.customer_id = c.id where cth.status = '1' AND cth.payment_type = 'Cheque' AND cth.action_type = 'Payment Cancelled' order by id desc  ";


	$customers = mysqli_query($conn,$query);

	if(mysqli_num_rows($customers) > 0){

		echo '<table border="1">';
		//make the column headers what you want in whatever order you want
		echo '<tr><th>Sr.</th>
							<th>Project Details</th>
							<th>Customer Details</th>
							<th>Amount</th>
							<th>Paid Date</th>
							<th>Bank Detail</th>
							<th>Remarks</th></tr>';
		//loop the query data to the table in same order as the headers
		$counter = 1;
		$total_debited_amt = $total_credited_amt = $total_pending_amt = 0;
								while($customer = mysqli_fetch_assoc($customers)){
									// echo "<pre>"; print_r($customer); die;
									$total_debited_amt += $total_debited = totalDebited($conn,$customer['customer_id'],$customer['block_id'],$customer['block_number_id']);
									$total_credited_amt += $total_credited = totalCredited($conn,$customer['customer_id'],$customer['block_id'],$customer['block_number_id']);
									
									$total_pending_amt += $pending_amount = ($total_credited - $total_debited);
									?>
		    <tr>
										<tr>
										<td><?php echo $counter; ?>.</td>
										<td>
											<strong>Project : </strong><?php echo $customer['project_name']; ?><br>
											<strong>Block : </strong><?php echo $customer['block_name']; ?><br>
											<strong>Plot No. : </strong><?php echo $customer['block_number_name']; ?>
												
										</td>

										<td>
											<strong>Name : </strong><?php echo ($customer['customer_name_title'].' ' .$customer['customer_name']).'<br>'.' ('.customerID($customer['customer_id']).')'; ?><br>
											<strong>Mobile : </strong><?php echo $customer['customer_mobile']; ?><br>
											<strong>Address : </strong><?php echo $customer['customer_address']; ?>
												
										</td>
										
										<td><?php echo $customer['amount']; ?></td>
										<td><?php echo $customer['paid_date'] ?></td>
										<td>
											<strong>Bank Name : </strong><?php echo $customer['bank_name']?$customer['bank_name']:'N/A'; ?><br>
											<strong>Cheque No : </strong><?php echo $customer['cheque_dd_number']?$customer['cheque_dd_number']:'N/A'; ?><br>
											<strong>Remarks : </strong><?php echo $customer['remarks']?$customer['remarks']:'N/A'; ?>
										</td>
										<td>
											<?php echo $customer['cancel_remarks']; ?>
										</td>
		   <?php  $counter++;
		}
	}
?>