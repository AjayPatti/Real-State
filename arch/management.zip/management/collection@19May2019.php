<?php
	ob_start();
	session_start();

	require("../includes/host.php");
	require("../includes/kc_connection.php");
	require("../includes/common-functions.php");
	require("../includes/checkAuth.php");

	$limit = 1000;
	if(isset($_GET['page'])){
		$page = $_GET['page'];
	}else{
		$page = 1;
	}

	$search = false;
	$query = "select * from kc_customer_transactions where status = '1' and cr_dr = 'dr' ";
	if( (isset($_GET['from_date']) && isset($_GET['to_date'])) || (isset($_GET['associate']) && $_GET['associate']>0) ){ 
		//echo "<pre>"; print_r($_GET); die;
		if(isset($_GET['from_date']) && isset($_GET['to_date'])){
			$query .= " and paid_date BETWEEN '".date("Y-m-d",strtotime($_GET['from_date']))."' AND '".date("Y-m-d",strtotime($_GET['to_date']))."'";
		}

		if(isset($_GET['associate']) && $_GET['associate']>0){
			$query .= " and block_number_id IN (select block_number_id from kc_customer_blocks where status = '1' and associate = '".$_GET['associate']."') ";
		}
		

		$total_records = mysqli_num_rows(mysqli_query($conn,$query));
		$total_pages = ceil($total_records/$limit);
		
		if($page == 1){
			$start = 0;
		}else{
			$start = ($page-1)*$limit;
		}

		$query .= " order by paid_date asc limit $start,$limit";
		$transactions = mysqli_query($conn,$query);
		$search = true;
	}	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Kanoujia City | Admin Panel</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <link href="/<?php echo $host_name; ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
    <link href="/<?php echo $host_name; ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="/<?php echo $host_name; ?>/css/ionicons.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Select2 -->
    <link href="/<?php echo $host_name; ?>/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
	
    <!-- Theme style -->
    <link href="/<?php echo $host_name; ?>/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="/<?php echo $host_name; ?>/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="/<?php echo $host_name; ?>/plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="/<?php echo $host_name; ?>/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="/<?php echo $host_name; ?>/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="/<?php echo $host_name; ?>/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="/<?php echo $host_name; ?>/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="/<?php echo $host_name; ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Developer Css -->
    <link href="/<?php echo $host_name; ?>/css/style.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/<?php echo $host_name; ?>/js/html5shiv.min.js"></script>
        <script src="/<?php echo $host_name; ?>/js/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php require('../includes/header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php echo require('../includes/left_sidebar.php'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Masters
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Business</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
			<div class="box">
                <div class="box-header">
					<?php 
					include("../includes/notification.php"); ?>
					<div class="col-sm-8">
						<h3 class="box-title">All Business</h3>
					</div>
                    <div class="col-sm-4">
                    	<?php if($search && mysqli_num_rows($transactions) > 0 && false){ ?>
							<a href="excel_export.php?from_date=<?php echo isset($_GET['from_date'])?$_GET['from_date']:''; ?>&to_date=<?php echo isset($_GET['to_date'])?$_GET['to_date']:''; ?>&sales_person=<?php echo isset($_GET['sales_person'])?$_GET['sales_person']:''; ?>&search=Search" class="btn btn-sm btn-success pull-right"><i class="fa fa-file-excel-o"></i> Excel Export</a>
						<?php } ?>
					</div>
					<hr />
					<form action="" name="search_frm" id="search_frm" method="get" class="">
						<div class="form-group col-sm-3">
							<label for="from_date">From</label>
						  	<input type="text" class="form-control" id="from_date" name="from_date" data-inputmask="'alias': 'dd-mm-yyyy'" data-mask=""  data-validation="date" data-validation-format="dd-mm-yyyy" />
						</div>
						<div class="form-group col-sm-3">
							<label for="to_date">To</label>
							<input type="text" class="form-control" id="to_date" name="to_date" data-inputmask="'alias': 'dd-mm-yyyy'" data-mask=""  data-validation="date" data-validation-format="dd-mm-yyyy" class="form-control" />
						</div>
						<div class="form-group col-sm-3">
						  	<label for="sales_person">Associate <span class="text-danger">*</span></label>
						  
							<select class="form-control" id="associate" name="associate">
								<option value="">Select Associate</option>
							    <?php
								$associates = mysqli_query($conn,"select * from kc_associates where status = '1' ");
								while($associate = mysqli_fetch_assoc($associates)){ ?>
							    	<option value="<?php echo $associate['id']; ?>"><?php echo $associate['name']; ?></option>
							    <?php } ?>
							</select>
						  
						</div>
						<input type="submit" name="search" value="Search" class="btn btn-sm btn-primary" style="margin-top: 25px;">
					</form>
				</div><!-- /.box-header -->
				
                <div class="box-body no-padding">
				
				 <table class="table table-striped table-hover table-bordered">
                    <tr>
						<th>Sr.</th>
						<th width="8%">Block</th>
						<th>Plot No.</th>
						<th>Area</th>
						<th>Client Name</th>
						<th>Associate</th>
						<th>Amount Received</th>
						<th>Payment Mode</th>
						<th>Date</th>
					</tr>
					<?php
						
						if($search && mysqli_num_rows($transactions) > 0){
							$counter = 1;
							$totalAmountReceived = $totalPendingAmount = 0;
							while($transaction = mysqli_fetch_assoc($transactions)){
								//$transaction = mysqli_fetch_assoc(mysqli_query($conn,"select * from uv_customer_transactions where customer_id = '".$block['customer_id']."' and block_id = '".$block['block_id']."' and block_number_id = '".$block['block_number_id']."' and cr_dr = 'dr' "));
								$block = mysqli_fetch_assoc(mysqli_query($conn,"select * from kc_customer_blocks where block_id = '".$transaction['block_id']."' and block_number_id = '".$transaction['block_number_id']."' limit 0,1 "));
								//echo "<pre>"; print_r($transaction);
								$total_debited = totalDebited($conn,$block['customer_id'],$block['block_id'],$block['block_number_id']);
								$total_credited = totalCredited($conn,$block['customer_id'],$block['block_id'],$block['block_number_id']);

								$block_details = mysqli_fetch_assoc(mysqli_query($conn,"select area from kc_block_numbers where block_id = '".$block['block_id']."' and id = '".$block['block_number_id']."' and status = '1' "));
								
								$totalAmountReceived += $transaction['amount'];

								$pending_amount = ($total_credited - $total_debited);
								$totalPendingAmount += $pending_amount;
								?>
								<tr>
									<td><?php echo $counter; ?>.</td>
									<td><?php echo blockName($conn,$transaction['block_id']); ?></td>
									<td><?php echo blockNumberName($conn,$transaction['block_number_id']); ?></td>
									<td><?php echo $block_details['area']; ?> Sq. Ft.</td>
									<td><?php echo customerName($conn,$transaction['customer_id']); ?></td>
									<td><?php echo ($block['associate'] > 0)?associateName($conn,$block['associate']):''; ?></td>
									<td><?php echo number_format($transaction['amount'],2); ?> ₹</td>
									<td><?php echo $transaction['payment_type']; ?></td>
									<td><?php echo date("d M Y",strtotime($transaction['paid_date'])); ?></td>
								</tr>
								<?php	
								$counter++;
							} ?>
							<tr>
								<td colspan="6" align="right"><font size="3">Total: &nbsp;&nbsp;</font></td>
								<td class="text-success"><font size="3"><?php echo number_format($totalAmountReceived,2); ?> ₹</font></td>
								<td colspan="6">&nbsp;</td>
								<?php /*<td colspan="6" class="text-danger"><font size="3"><?php echo number_format($totalPendingAmount,2); ?> ₹</font></td>*/ ?>
							</tr>
							<?php
						}else{
							?>
							<tr>
								<td colspan="13" align="center"><h4 class="text-red">No Record Found</h4></td>
							</tr>
							<?php
						}
						?>
                  </table>
                </div><!-- /.box-body -->
				
				<?php if(isset($total_pages) && $total_pages > 1){ ?>
					<div class="box-footer clearfix">
					  <ul class="pagination pagination-sm no-margin pull-right">
					   
						<?php
							for($i = 1; $i <= $total_pages; $i++){
								?>
								 <li <?php if((isset($_GET['page']) && $i == $_GET['page']) || (!isset($_GET['page']) && $i == 1)){ ?>class="active"<?php } ?>><a href="plc.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php
							}
						?>
						
					  </ul>
					</div>
				<?php } ?>
				
              </div><!-- /.box -->
        </section> 
          
      </div><!-- /.content-wrapper -->    
      <?php require('../includes/footer.php'); ?>

      <?php require('../includes/control-sidebar.php'); ?>
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <?php require('../includes/common-js.php'); ?>
	
    <script type="text/javascript">
	
	</script>
    
  </body>
</html>