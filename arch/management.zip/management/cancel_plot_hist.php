<?php
	ob_start();
	session_start();

	require("../includes/host.php");
	require("../includes/kc_connection.php");
	require("../includes/common-functions.php");
	require("../includes/checkAuth.php");
	if(!(userCan($conn,$_SESSION['login_id'],$privilegeName = 'manage_cancel_plot_hist'))){ 
	 	header("location:/kanoujia/index.php");
	 	exit();
 	}

 	if(isset($_POST['addTransaction']) && $_POST['addTransaction']=="Save Changes"){
		$refund_amount = filter_post($conn,$_POST['refund_amount']);
		$refund_remarks = filter_post($conn,$_POST['refund_remarks']);
		$refund_id = filter_post($conn,$_POST['refund_id']);
		$refund_customer_id = filter_post($conn,$_POST['refund_customer_id']);
		$refund_block_id = filter_post($conn,$_POST['refund_block_id']);
		$refund_block_number_id = filter_post($conn,$_POST['refund_block_number_id']);

		$block_number = mysqli_fetch_assoc(mysqli_query($conn,"select * from kc_customer_blocks_hist where status = '1' and action_type = 'Cancel Booking' and id = '$refund_id' "));
							
		$total_deposit = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as Deposited from kc_customer_transactions_hist where customer_id = '".$block_number['customer_id']."' and block_id = '".$block_number['block_id']."' and block_number_id = '".$block_number['block_number_id']."' and cr_dr = 'cr' and action_type = 'Cancel Booking' and addedon <= '".$block_number['addedon']."' and deleted >= '".$block_number['deleted']."' "));

		$total_paid = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as Paid from kc_customer_transactions_hist where customer_id = '".$block_number['customer_id']."' and block_id = '".$block_number['block_id']."' and block_number_id = '".$block_number['block_number_id']."'  and cr_dr = 'dr' and action_type = 'Cancel Booking' and addedon <= '".$block_number['addedon']."' and deleted >= '".$block_number['deleted']."' "));

		$total_refund = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as Refunded from kc_refund_amount where customer_id = '".$block_number['customer_id']."' and block_id = '".$block_number['block_id']."' and block_number_id = '".$block_number['block_number_id']."' and customer_blocks_hist_id = '".$block_number['id']."' "));
		
		$refunded_amount = ($total_paid['Paid']+$total_refund['Refunded']+$refund_amount);
		if($refund_amount == ''){
			$_SESSION['error'] = 'Refund amount was wrong!';
		}else if(!is_numeric($refund_amount) || !($refund_amount > 0)){
			$_SESSION['error'] = 'Refund amount was wrong!';
		}else if($total_deposit['Deposited'] < $refunded_amount){
			$_SESSION['error'] = 'Refunded amount is greater than refund amount!';
		}else if($refund_remarks == ''){
			$_SESSION['error'] = 'Refund remark was wrong!';
		}else if($refund_id == ''){
			$_SESSION['error'] = 'Something was wrong!';
		}else if(!is_numeric($refund_id) || !($refund_id > 0)){
			$_SESSION['error'] = 'Something was wrong!';
		}else if($refund_customer_id == ''){
			$_SESSION['error'] = 'Customer was wrong!';
		}else if(!is_numeric($refund_customer_id) || !($refund_customer_id > 0)){
			$_SESSION['error'] = 'Customer was wrong!';
		}else if($refund_block_id == ''){
			$_SESSION['error'] = 'Block was wrong!';
		}else if(!is_numeric($refund_block_id) || !($refund_block_id > 0)){
			$_SESSION['error'] = 'Block was wrong!';
		}else if($refund_block_number_id == ''){
			$_SESSION['error'] = 'Block number was wrong!';
		}else if(!is_numeric($refund_block_number_id) || !($refund_block_number_id > 0)){
			$_SESSION['error'] = 'Block number was wrong!';
		}else{
			mysqli_query($conn,"insert into kc_refund_amount set customer_blocks_hist_id = '$refund_id', customer_id = '$refund_customer_id', block_id = '$refund_block_id', block_number_id = '$refund_block_number_id', amount = '$refund_amount', remark = '$refund_remarks', status = '1', added_by = '".$_SESSION['login_id']."', addedon = '".date('Y-m-d H:i:s')."' ");

			$insert = mysqli_commit($conn);

			if($insert){
				$_SESSION['success'] = 'Refund amount has been Successfully Saved!';
				header("Location:cancel_plot_hist.php");
				exit();
			}else{
				$_SESSION['error'] = 'Something Problem Occured!';
				header("Location:cancel_plot_hist.php");
				exit();
			}
		 
	} 
}

	if(isset($_GET['id']))
	{
	  // $del = $_POST['delete'];
		$id = $_GET['id'];
		mysqli_query($conn,"update `kc_refund_amount` set deleted= '".date('Y-m-d H:i:s')."' WHERE id=$id");
		$insert = mysqli_commit($conn);
		if($insert){
			$_SESSION['success'] = 'Extra Entry Deleted Successfully!';
			header('location:cancel_plot_hist.php');
			exit();
		}else{
			$_SESSION['error'] = 'Something Problem Occured!';
			header("Location:cancel_plot_hist.php");
			exit();
		}
			
	}
		
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Kanoujia City | Admin Panel</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <link href="/<?php echo $host_name; ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
    <link href="/<?php echo $host_name; ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="/<?php echo $host_name; ?>/css/ionicons.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Select2 -->
    <link href="/<?php echo $host_name; ?>/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
    
    <!-- jQuery UI -->
    <link href="/<?php echo $host_name; ?>/css/jquery-ui.css" rel="stylesheet" type="text/css" />
	
    <!-- Theme style -->
    <link href="/<?php echo $host_name; ?>/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="/<?php echo $host_name; ?>/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="/<?php echo $host_name; ?>/plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="/<?php echo $host_name; ?>/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="/<?php echo $host_name; ?>/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="/<?php echo $host_name; ?>/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="/<?php echo $host_name; ?>/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="/<?php echo $host_name; ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Developer Css -->
    <link href="/<?php echo $host_name; ?>/css/style.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/<?php echo $host_name; ?>/js/html5shiv.min.js"></script>
        <script src="/<?php echo $host_name; ?>/js/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    	.ui-autocomplete li{
    		font-family: 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif;
    		padding: 5px 8px;
    		font-weight: bold;
    	}
    	.ui-autocomplete li:hover{
    		background-color: #3c8dbc;
    		color: white;
    	}
    </style>
    <script>
    	function printDiv(divName) {
		     var printContents = document.getElementById(divName).innerHTML;
		     var originalContents = document.body.innerHTML;

		     document.body.innerHTML = printContents;

		     window.print();

		     document.body.innerHTML = originalContents;
		}
    </script>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php require('../includes/header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php echo require('../includes/left_sidebar.php'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Masters
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Cancel Plot Report</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
			<div class="box">
                <div class="box-header">
					<?php 
					include("../includes/notification.php"); ?>
					<div class="col-sm-10">
						<h3 class="box-title">Cancel Plot Report</h3>
					</div>
                   <!--  <div class="col-sm-1">
							<a href="cancel_plot_report_excel_export.php" class="btn btn-sm btn-success pull-right"><i class="fa fa-file-excel-o"></i> Excel Export</a>
					</div>
					<div class="col-sm-1">
							<a class="btn btn-sm btn-danger" href="javascript:void(0);" onclick="printDiv('printContent')" data-toggle="tooltip" title="Print"><i class="fa fa-print">&nbsp;</i>PDF Export</a>
					</div> -->
					
				</div><!-- /.box-header -->
				
                <div class="box-body no-padding" id="printContent">
				 <div class="table-responsive">
					 <table class="table table-striped table-hover table-bordered">
	                    <tr>
							<th>Sr.</th>
							<th>Project Details</th>
							<th>Customer Details</th>
		                    <th>Final Plot Amount</th>
		                    <th>Deposited</th>
	                      	<th>Refunded</th>
	                      	<th>Pending Refund</th>
	                      	<th>Cancel Date</th>
	                      	<th>Action</th>
						</tr>
						<?php
							$limit = 100;
							if(isset($_GET['page'])){
								$page = $_GET['page'];
							}else{
								$page = 1;
							}

						$total_records = mysqli_fetch_assoc(mysqli_query($conn,"select COUNT(*) as total from kc_customer_blocks_hist where status = '1' and action_type = 'Cancel Booking'"));
						$total_pages = ceil($total_records['total']/$limit);
							
						if($page == 1){
							$start = 0;
						}else{
							$start = ($page-1)*$limit;
						}

						$query =  "select cbh.id as customer_block_id,cbh.id,cbh.deleted, cbh.customer_id, cbh.block_id, cbh.block_number_id, cbh.registry, cbh.registry_date, cbh.registry_by, cbh.associate,b.project_id, b.name as block_name, bn.block_number as block_number_name, bn.area, p.name as project_name, c.name_title as customer_name_title, c.name as customer_name, c.mobile as customer_mobile, c.address as customer_address,a.code as associate_code, a.name as associate_name from kc_customer_blocks_hist cbh LEFT JOIN kc_blocks b ON cbh.block_id = b.id LEFT JOIN kc_block_numbers bn ON cbh.block_number_id = bn.id LEFT JOIN kc_projects p ON b.project_id = p.id LEFT JOIN kc_customers c ON cbh.customer_id = c.id LEFT JOIN kc_associates a ON cbh.associate = a.id where cbh.status = '1' AND cbh.action_type = 'Cancel Booking'  order by id desc limit $start,$limit";
						$customers = mysqli_query($conn,$query);

							if(mysqli_num_rows($customers) > 0){
								$counter = $start+1;
								$total_debited_amt = $total_credited_amt = $total_pending_amt = 0;
								while($customer = mysqli_fetch_assoc($customers)){
								// echo ;die();	
								$total_amount_details = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as total_amount from kc_customer_transactions_hist where customer_id = '".$customer['customer_id']."' and block_id = '".$customer['block_id']."' and block_number_id = '".$customer['block_number_id']."' and cr_dr = 'cr' and status = '1' and action_type = 'Cancel Booking'"));
								$total_amount = $total_amount_details['total_amount']?$total_amount_details['total_amount']:0;

								$total_paid_details = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as total_paid from kc_customer_transactions_hist where customer_id = '".$customer['customer_id']."' and block_id = '".$customer['block_id']."' and block_number_id = '".$customer['block_number_id']."' and cr_dr = 'dr' and status = '1' and remarks is NULL and action_type = 'Cancel Booking'"));
								$total_paid = $total_paid_details['total_paid']?$total_paid_details['total_paid']:0;

								$total_discount_details = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as total_discount from kc_customer_transactions_hist where customer_id = '".$customer['customer_id']."' and block_id = '".$customer['block_id']."' and block_number_id = '".$customer['block_number_id']."' and cr_dr = 'dr' and status = '1' and remarks is NOT NULL and action_type = 'Cancel Booking'"));
								$total_discount = $total_discount_details['total_discount']?$total_discount_details['total_discount']:0;

								$final_amount = $total_amount - $total_discount;
								 $total_refund = mysqli_fetch_assoc(mysqli_query($conn,"select sum(amount) as total_refunded from kc_refund_amount where customer_id = '".$customer['customer_id']."' and block_id = '".$customer['block_id']."' and block_number_id = '".$customer['block_number_id']."' and deleted is null"));
								 $total_refunded = $total_refund['total_refunded']?$total_refund['total_refunded']:0;
								
								 $pending_amount = ($total_paid-$total_refunded);

								?>
									<tr>
										<td><?php echo $counter; ?>.</td>
										<td>
											<strong>Project : </strong><?php echo $customer['project_name']; ?><br>
											<strong>Block : </strong><?php echo $customer['block_name']; ?><br>
											<strong>Plot No. : </strong><?php echo $customer['block_number_name']; ?>
												
										</td>

										<td>
											<strong>Name : </strong><?php echo ($customer['customer_name_title'].' ' .$customer['customer_name']).'<br>'.' ('.customerID($customer['customer_id']).')'; ?><br>
											<strong>Mobile : </strong><?php echo $customer['customer_mobile']; ?><br>
											<strong>Address : </strong><?php echo $customer['customer_address']; ?>
												
										</td>
										<td nowrap="nowrap"><span class="text-success"><?php echo $final_amount; ?> <i class="fa fa-inr"></i></span></td>
		                                <td nowrap="nowrap"><span class="text-success"><?php echo $total_paid; ?> <i class="fa fa-inr"></i></span></td>
		                                <td nowrap="nowrap"><span class="text-info"><?php echo $total_refunded?$total_refunded:0; ?> <i class="fa fa-inr"></i></span></td>
		                                <td nowrap="nowrap"><span class="text-danger"><?php echo ($pending_amount?$pending_amount:0); ?> <i class="fa fa-inr"></i></span></td>
		                                <td width="8%"><?php echo date("d M Y h:i A",strtotime($customer['deleted'])); ?></td>
		                                <td width="8%">
		                                	<?php if(userCan($conn,$_SESSION['login_id'],$privilegeName = 'view_transaction_cancel_plot_hist')){  ?>
		                                	<button class="btn btn-xs btn-info" onClick="getTransactions(<?php echo $customer['customer_block_id']; ?>);" data-toggle="tooltip" title="View Old Transactions"><i class="fa fa-eye"></i></button> 
		                                	<?php } if(userCan($conn,$_SESSION['login_id'],$privilegeName = 'add_refund_cancel_plot_hist')){
		                                	 if($pending_amount > 0){ ?>
			                                	<button class="btn btn-xs btn-primary" type="button" data-toggle="tooltip" title="Add Refund Amount" onclick = "addRefundAmount(<?php echo $customer['customer_block_id']; ?>);"> <i class="fa fa-plus"></i> </button>
			                                <?php } }
			                                if(userCan($conn,$_SESSION['login_id'],$privilegeName = 'view_refund_cancel_plot_hist')){
			                                if($total_refund['total_refunded']>0){ ?>
				                                  <button class="btn btn-xs btn-warning" onClick="getRefundTransactions(<?php echo $customer['customer_block_id']; ?>);" data-toggle="tooltip" title="View Refund Transactions"><i class="fa fa-money"></i></button> 
				                            <?php } } ?>
				                        </td>
									</tr>
									<?php	
									$counter++;
								} ?>
								
								<?php
							}else{
								?>
								<tr>
									<td colspan="16" align="center"><h4 class="text-red">No Record Found</h4></td>
								</tr>
								<?php
							}
							?>
	                  </table>
              		</div>
                </div><!-- /.box-body -->
				
				<?php if(isset($total_pages) && $total_pages > 1){ ?>
					<div class="box-footer clearfix">
					  <ul class="pagination pagination-sm no-margin pull-right">
					   
						<?php
							for($i = 1; $i <= $total_pages; $i++){
								?>
								 <li <?php if((isset($_GET['page']) && $i == $_GET['page']) || (!isset($_GET['page']) && $i == 1)){ ?>class="active"<?php } ?>><a href="cancel_plot_hist.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php
							}
						?>
						
					  </ul>
					</div>
				<?php } ?>
				
              </div><!-- /.box -->
        </section> 
          
      </div><!-- /.content-wrapper -->    
      <?php require('../includes/footer.php'); ?>

      <?php require('../includes/control-sidebar.php'); ?>
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->
<div class="modal" id="addRefundAmount">
	  <div class="modal-dialog">
		<div class="modal-content">
			<form enctype="multipart/form-data" action="" name="add_refund_frm" id="add_refund_frm" method="post" class="form-horizontal dropzone has-validation-callback">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
				<h4 class="modal-title">Add Refund Amount</h4>
			  </div>
			  <div class="modal-body">
				<div class="box box-info">
					<div class="box-header with-border">
						<div class="col-md-12">
							<h3 class="box-title">Add Refund Amount Panel</h3>
						</div>
					</div><!-- /.box-header -->
					<!-- form start -->
					<div class="box-body" id="add-refund-amount-container">
						
                    </div><!-- /.box-body -->
					
				</div><!-- /.box -->
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary" id="addTransactionBtn" name="addTransaction" value="Save Changes">Save Changes</button>
			  </div>
			</form>
		</div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->

	<div class="modal" id="viewRefundTransaction">
	  <div class="modal-dialog">
		<div class="modal-content">
			<form enctype="multipart/form-data" action="" name="view_refund_transaction_frm" id="view_refund_transaction_frm" method="post" class="form-horizontal dropzone">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">All Transactions</h4>
			  </div>
			  <div class="modal-body">
				<div class="box box-info">
					<div class="box-body">
						
                        <table class="table table-bordered" id="view-refund-transaction-container">
                        </table>
                        
                        
                        
                        
						
					</div><!-- /.box-body -->
					
				</div><!-- /.box -->
			  </div>
			  
			</form>
		</div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->

	<div class="modal" id="viewTransaction">
	  <div class="modal-dialog">
		<div class="modal-content">
			<form enctype="multipart/form-data" action="" name="view_transaction_frm" id="view_transaction_frm" method="post" class="form-horizontal dropzone">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">All Transactions</h4>
			  </div>
			  <div class="modal-body">
				<div class="box box-info">
					<div class="box-body">
						
                        <table class="table table-bordered" id="view-transaction-container">
                        </table>
                        
                        
                        
                        
						
					</div><!-- /.box-body -->
					
				</div><!-- /.box -->
			  </div>
			  
			</form>
		</div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
    <?php require('../includes/common-js.php'); ?>
	<script type="text/javascript">
		function addRefundAmount(block_number){
			$.ajax({
				url: '../dynamic/RefundAmount.php',
				type:'post',
				data:{block_number:block_number},
				success: function(resp){
					$("#add-refund-amount-container").html(resp);
					$("#addRefundAmount").modal('show');
				}
			});
		}

		function getRefundTransactions(customer_blocks_hist_id){
			$.ajax({
				url: '../dynamic/getRefundTransactions.php',
				type:'post',
				data:{customer_blocks_hist_id:customer_blocks_hist_id},
				success: function(resp){
					$("#view-refund-transaction-container").html(resp);
					$("#viewRefundTransaction").modal('show');
				}
			});
		}

		function getTransactions(hist){
			$.ajax({
				url: '../dynamic/getCancelTransactions.php',
				type:'post',
				data:{hist:hist},
				success: function(resp){
					$("#view-transaction-container").html(resp);
					$("#viewTransaction").modal('show');
				}
			});
		}
	</script>
	
    
  </body>
</html>