<?php
	ob_start();
	session_start();

	require("../includes/host.php");
	require("../includes/kc_connection.php");
	require("../includes/common-functions.php");
	require("../includes/checkAuth.php");

	$url = 'report.php?search=Search';

	$limit = 500;
	if(isset($_GET['page'])){
		$page = $_GET['page'];
	}else{
		$page = 1;
	}

	$search = false;

	$query = "select * from kc_customer_blocks where status = '1' ";
	if(isset($_GET['search_project']) || isset($_GET['search_block']) || isset($_GET['search_block_no']) || (isset($_GET['search_block_no']) && $_GET['search_block_no']>0) || (isset($_GET['search_associate']) && (int) $_GET['search_associate'] > 0)){ 
		//echo "<pre>"; print_r($_GET); die;
		if(isset($_GET['search_block']) && $_GET['search_block']!=''){
			$query .= " and block_id = '".$_GET['search_block']."'";
			$url .= '&search_block='.$_GET['search_block'];
		}

		if(isset($_GET['search_block_no']) && $_GET['search_block_no']!=''){
			$query .= " and block_number_id = '".$_GET['search_block_no']."'";
			$url .= '&search_block_no='.$_GET['search_block_no'];
		}

		if(isset($_GET['search_project']) && $_GET['search_project']>0){
			$query .= " and block_id IN (select id from kc_blocks where status = '1' and project_id = '".$_GET['search_project']."' )";
			$url .= '&search_project='.$_GET['search_project'];
		}

		if(isset($_GET['search_associate']) && (int) $_GET['search_associate'] > 0){
			$associate_id = (int) $_GET['search_associate'];
			$query .= " and associate = '$associate_id'";
			$url .= '&search_associate='.$_GET['search_associate'];
		}
		
		$total_records = mysqli_num_rows(mysqli_query($conn,$query));
		$total_pages = ceil($total_records/$limit);
		
		if($page == 1){
			$start = 0;
		}else{
			$start = ($page-1)*$limit;
		}

		$query .= " order by registry_date desc limit $start,$limit";
		$customers = mysqli_query($conn,$query);
		$search = true;
	}	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Kanoujia City | Admin Panel</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <link href="/<?php echo $host_name; ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
    <link href="/<?php echo $host_name; ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="/<?php echo $host_name; ?>/css/ionicons.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Select2 -->
    <link href="/<?php echo $host_name; ?>/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
    
    <!-- jQuery UI -->
    <link href="/<?php echo $host_name; ?>/css/jquery-ui.css" rel="stylesheet" type="text/css" />
	
    <!-- Theme style -->
    <link href="/<?php echo $host_name; ?>/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="/<?php echo $host_name; ?>/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="/<?php echo $host_name; ?>/plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="/<?php echo $host_name; ?>/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="/<?php echo $host_name; ?>/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="/<?php echo $host_name; ?>/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="/<?php echo $host_name; ?>/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="/<?php echo $host_name; ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Developer Css -->
    <link href="/<?php echo $host_name; ?>/css/style.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/<?php echo $host_name; ?>/js/html5shiv.min.js"></script>
        <script src="/<?php echo $host_name; ?>/js/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    	.ui-autocomplete li{
    		font-family: 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif;
    		padding: 5px 8px;
    		font-weight: bold;
    	}
    	.ui-autocomplete li:hover{
    		background-color: #3c8dbc;
    		color: white;
    	}
    </style>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php require('../includes/header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php echo require('../includes/left_sidebar.php'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Masters
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Report</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
			<div class="box">
                <div class="box-header">
					<?php 
					include("../includes/notification.php"); ?>
					<div class="col-sm-2">
						<h3 class="box-title">All Report</h3>
					</div>
                    <div class="col-sm-10">
                    	<?php if($search && mysqli_num_rows($customers) > 0){ ?>
							<a href="report_excel_export.php?search_project=<?php echo isset($_GET['search_project'])?$_GET['search_project']:''; ?>&search_block=<?php echo isset($_GET['search_block'])?$_GET['search_block']:''; ?>&search_block_no=<?php echo isset($_GET['search_block_no'])?$_GET['search_block_no']:''; ?>&search_associate=<?php echo isset($_GET['search_associate'])?$_GET['search_associate']:''; ?>&search=Search" class="btn btn-sm btn-success pull-right"><i class="fa fa-file-excel-o"></i> Excel Export</a>
						<?php } ?>
					</div>
					<hr />
					<form action="" name="search_frm" id="search_frm" method="get" class="">
						<div class="form-group col-sm-3">
							<label for="search_project" class="col-md-12 text-left">Project</label>
						  	<select class="form-control" id="search_project" name="search_project" onChange="search_getBlocks(this.value);">
	                        	<option value="">Select Project</option>
	                            <?php
								$projects = mysqli_query($conn,"select * from kc_projects where status = '1' ");
								while($project = mysqli_fetch_assoc($projects)){ ?>
	                            	<option value="<?php echo $project['id']; ?>"><?php echo $project['name']; ?></option>
	                            <?php } ?>
                        	</select>
						</div>
						<div class="form-group col-md-2 text-center">
						  	<label for="search_block" class="col-md-12 text-left">Block</label>
							<select class="form-control" id="search_block" name="search_block" onChange="search_getBlockNumbers(this.value);">
						        <option value="">Select Block</option>
						    </select>
						</div>
						<div class="form-group col-md-2 text-center">
						  	<label for="search_block_no" class="col-md-12 text-left">Plot Number</label>
							<select class="form-control" id="search_block_no" name="search_block_no">
						        <option value="">Select Plot Number</option>
						    </select>
						</div>
						<div class="form-group col-md-3 text-center">
							<label for="search_associate" class="col-md-12 text-left">Associate</label>
							<select class="form-control" id="search_associate" name="search_associate">
						        <option value="">Select Associate</option>
						        <?php
								$associates = mysqli_query($conn,"select * from kc_associates where status = '1' ");
								while($associate = mysqli_fetch_assoc($associates)){ ?>
						        	<option value="<?php echo $associate['id']; ?>"><?php echo $associate['name']; ?></option>
						        <?php } ?>
						    </select>
						</div>
						<input type="submit" name="search" value="Search" class="btn btn-sm btn-primary" style="margin-top: 25px;">
					</form>
				</div><!-- /.box-header -->
				
                <div class="box-body no-padding">
				
				 <table class="table table-striped table-hover table-bordered">
                    <tr>
						<th>Sr.</th>
						<th>Project</th>
						<th width="8%">Block</th>
						<th>Plot No.</th>
						<th>Customer</th>
						<th>Associate</th>
						<th>Rate</th>
						<th>Area</th>
						<th>Amount</th>
						<th>Received Amount</th>
						<th>Pending Amount</th>
					</tr>
					<?php
						
						if($search && mysqli_num_rows($customers) > 0){
							$counter = 1;
							$total_debited_amt = $total_credited_amt = $total_pending_amt = 0;
							while($customer = mysqli_fetch_assoc($customers)){
								//echo "<pre>"; print_r($customer); die;
								$total_debited_amt += $total_debited = totalDebited($conn,$customer['customer_id'],$customer['block_id'],$customer['block_number_id']);
								$total_credited_amt += $total_credited = totalCredited($conn,$customer['customer_id'],$customer['block_id'],$customer['block_number_id']);

								$block_details = mysqli_fetch_assoc(mysqli_query($conn,"select area from kc_block_numbers where block_id = '".$customer['block_id']."' and id = '".$customer['block_number_id']."' and status = '1' "));
								
								$total_pending_amt += $pending_amount = ($total_credited - $total_debited);
								?>
								<tr>
									<td><?php echo $counter; ?>.</td>
									<td><?php echo blockProjectName($conn,$customer['block_id']); ?></td>
									<td><?php echo blockName($conn,$customer['block_id']); ?></td>
									<td><?php echo blockNumberName($conn,$customer['block_number_id']); ?></td>
									<td><?php echo customerName($conn,$customer['customer_id']).' ('.customerID($customer['customer_id']).')'; ?></td>
									<td><?php echo ($customer['associate'] > 0)?associateName($conn,$customer['associate']):''; ?></td>
									<td>
										<span class="text-warning"><?php echo ($customer['rate_per_sqft'] > 0)?$customer['rate_per_sqft']:''; ?> ₹</span>
									</td>
									<td><?php echo $block_details['area']; ?> Sq. Ft.</td>
									<td>
										<span class="text-primary"><?php echo number_format($total_credited,2); ?> ₹</span>
									</td>
									<td>
										<span class="text-success"><?php echo number_format($total_debited,2); ?> ₹</span>
									</td>
									<td>
										<span class="text-danger"><?php echo number_format($pending_amount,2); ?> ₹</span>
									</td>
								</tr>
								<?php	
								$counter++;
							} ?>
							<tr>
								<td colspan="8" align="right">Total</td>
								<td>
									<span class="text-primary"><?php echo number_format($total_credited_amt,2); ?> ₹</span>
								</td>
								<td>
									<span class="text-success"><?php echo number_format($total_debited_amt,2); ?> ₹</span>
								</td>
								<td>
									<span class="text-danger"><?php echo number_format($total_pending_amt,2); ?> ₹</span>
								</td>
							</tr>
							<?php
						}else{
							?>
							<tr>
								<td colspan="9" align="center"><h4 class="text-red">No Record Found</h4></td>
							</tr>
							<?php
						}
						?>
                  </table>
                </div><!-- /.box-body -->
				
				<?php if(isset($total_pages) && $total_pages > 1){ ?>
					<div class="box-footer clearfix">
					  <ul class="pagination pagination-sm no-margin pull-right">
					   
						<?php
							for($i = 1; $i <= $total_pages; $i++){
								?>
								 <li <?php if((isset($_GET['page']) && $i == $_GET['page']) || (!isset($_GET['page']) && $i == 1)){ ?>class="active"<?php } ?>><a href="<?php echo $url; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php
							}
						?>
						
					  </ul>
					</div>
				<?php } ?>
				
              </div><!-- /.box -->
        </section> 
          
      </div><!-- /.content-wrapper -->    
      <?php require('../includes/footer.php'); ?>

      <?php require('../includes/control-sidebar.php'); ?>
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <?php require('../includes/common-js.php'); ?>
	
    <script type="text/javascript">
		$( function() {
		    $( "#customer" ).autocomplete({
				source: function( request, response ) {
			        $.ajax( {
			          url: "../dynamic/getCustomers.php",
			          type:"post",
			          dataType: "json",
			          data: {
			            term: request.term
			          },
			          success: function( data ) {
			            //alert(data);
			            response( data );
			          }
			        } );
			      },
				minLength: 2,
				select: function( event, ui ) {
					//log( "Selected: " + ui.item.value + " aka " + ui.item.id );
					window.location.href = 'ledger.php?customer='+ui.item.id+'&name='+ui.item.label;
				}
	    	});
	  	});

	  	function search_getBlocks(project){
			$("#search_block_no").val('');
			$.ajax({
				url: '../dynamic/getBlocks.php',
				type:'post',
				data:{project:project},
				success: function(resp){
					$("#search_block").html(resp);
				}
			});
		}

		function search_getBlockNumbers(block){
			$.ajax({
				url: '../dynamic/getBlockNumbers.php',
				type:'post',
				data:{block:block, type: 'booked'},
				success: function(resp){
					if(resp.trim() != ''){
						$("#search_block_no").html(resp);
					}else{
						$("#search_block_no").html('<option value="">Select Plot Number</option>');
					}
				}
			});
		}
	</script>
    
  </body>
</html>