<?php
ob_start();
session_start();

require("../includes/host.php");
require("../includes/kc_connection.php");
require("../includes/common-functions.php");
require("../includes/checkAuth.php");
require("../includes/sendMail.php");
require("../includes/sendMessage.php");


if(isset($_POST['template']) && isset($_POST['contacts']) && is_array($_POST['contacts']) && sizeof($_POST['contacts']) > 0 && is_array($_POST['names']) && sizeof($_POST['contacts']) <= sizeof($_POST['names'])){
	
	$message_count = 0;
	foreach($_POST['contacts'] as $key => $mobile_no){
		if(isset($_POST['names'][$key]) && strlen($mobile_no) == 10){
			//$message
			$variables_array = array_filter($_POST['variables']);
			$variables_array['variable1'] = $_POST['names'][$key];
      		//echo "<pre>"; print_r($variables_array); die;
			if(sendMessage($_POST['template'],$mobile_no,$variables_array)){
				$message_count++;
			}
		}
	}

	if($message_count > 0){
		$_SESSION['success'] = $message_count.' messages sent successfully.';
	}else{
		$_SESSION['error'] = 'No messages sent.';
	}
	header("location:send_message.php");
	exit();
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Kanoujia City | Admin Panel</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
    <link href="/<?php echo $host_name; ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
    <link href="/<?php echo $host_name; ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="/<?php echo $host_name; ?>/css/ionicons.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Select2 -->
    <link href="/<?php echo $host_name; ?>/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
	
    <!-- Theme style -->
    <link href="/<?php echo $host_name; ?>/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="/<?php echo $host_name; ?>/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="/<?php echo $host_name; ?>/plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="/<?php echo $host_name; ?>/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="/<?php echo $host_name; ?>/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="/<?php echo $host_name; ?>/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="/<?php echo $host_name; ?>/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="/<?php echo $host_name; ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<!-- Developer Css -->
    <link href="/<?php echo $host_name; ?>/css/style.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/<?php echo $host_name; ?>/js/html5shiv.min.js"></script>
        <script src="/<?php echo $host_name; ?>/js/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
      .btn-app{
        color: white;
        border: none;
      }
    </style>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php require('../includes/header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php echo require('../includes/left_sidebar.php'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Masters
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Send Message</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
			<div class="box">
        <div class="box-header">
					<?php 
					include("../includes/notification.php"); ?>
					<div class="col-sm-4">
						<h3 class="box-title">Send Message</h3>
					</div>
          <div class="col-sm-8">
              <div class="col-sm-2">
                <a href="send_message.php" class="btn btn-app btn-primary" style="background-color: #3c8dbc;">
                  <i class="fa fa-bars"></i> All
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=associate" class="btn btn-app btn-info" style="background-color: #00c0ef;">
                  <i class="fa fa-tree"></i> Associate
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=contacts" class="btn btn-app btn-danger" style="background-color: #d73925;">
                  <i class="fa fa-bookmark"></i> Contacts
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=customers" class="btn btn-app btn-success" style="background-color: #00a65a;">
                  <i class="fa fa-users"></i> Customers
                </a>
              </div>
              <div class="col-sm-2">
                <a href="send_message.php?type=employees" class="btn btn-app btn-warning" style="background-color: #f0ad4e;">
                  <i class="fa fa-user"></i> Employees
                </a>
              </div>
          </div>
        </div><!-- /.box-header -->
        <div class="box-body no-padding">
        	<form enctype="multipart/form-data" action="send_message.php" name="send_message_frm" id="send_message_frm" method="post" class="form-horizontal dropzone">
                 <div class="col-sm-12">
                    <div class="form-group">
                      <label for="excel_file" class="col-sm-3 control-label">Select Template</label>
                      <div class="col-sm-8">
                        <select class="form-control" id="template" name="template" required>
                            <option value="">Select Template</option>
                            <option value="1">Dear VAR1, Happy VAR2 from Team Kanoujia City.</option>
                            <option value="4">Kanoujia City wishes you & your family a very blissful, cheerful, colorful New Year with a smile.Best Regards,Team Kanoujia City</option>
                            <option value="5">Dear VAR1,  VAR2 Best Regards, Team Kanoujia City</option>
                            
                            <option value="7">An auspicious day to start with any good work May this day clear all hurdles of your life and start new era of well-being Happy Dussehra Team Kanoujia City</option>
                            
                            <option value="8">May the light that we celebrate at Diwali show us the way and lead us together on the path of social peace and harmony.Happy Diwali Team Kanoujia City</option>

                            <option value="9">Best wishes for joy and love this Christmas season, for you and your family.
Merry Christmas Team Kanoujia City</option>

                            <option value="10">Kanoujia City wishes you & your family a very blissful, cheerful, colorful New Year with a smile. Best Regards, Team Kanoujia City</option>

                            <option value="11">We hope that this New Year further strengthens the respect and mutual trust we have for each other, Happy New Year to you and your family Team UVHomes</option>

                            <option value="12">Kites flying high to touch the happiness, Til mangled with sweet to spread sweetness. Wish you a very Happy Makar Sankranti Team Kanoujia City</option>
                            
                            <option value="13">May you be bestowed with knowledge and wisdom by Goddess Saraswati. Have a blessed Basant Panchami! Team Kanoujia City</option>

                            
                            <option value="14">Dear VAR1 Thank you for choosing Kanoujia City. We have received Rs VAR2 against unit no. VAR3 as booking confirmation amount on VAR4 In case of any enquiry related to your plot you can reach us on VAR5 Kindly note cheque is subject to clearance.Thank you Team Kanoujia City</option>

                            <option value="15">Dear VAR1 We are glad to inform you that we have received VAR2 as VAR3 installment for plot no VAR4 On VAR5 .In case of any related enquiry you can reach us on VAR6 Thank you Team Kanoujia City</option>

                            <option value="16">Dear VAR1 Gentle reminder about your installment which is still outstanding for amount VAR2 You are requested to pay it by VAR3 to avoid late payment charges. Kindly ignore if already paid. In case of any further enquiry you can reach us on VAR4 Thank you Team Kanoujia City</option>

                            <option value="17">Dear VAR1 Welcome to Kanoujia City,Your site visit has been scheduled on VAR2 at VAR3 In case you need any changes regarding the same, you can reach us on VAR4 .Thank you Team Kanoujia City</option>

                            <option value="18">Dear Sir, Warm welcome to Kanoujia City As we know your previous site visit was cancelled, now you may contact VAR2 for booking a site visit at the earliest.Thank you Team Kanoujia City</option>

                            <option value="19">Dear VAR1 Greeting from Kanoujia City, We are delighted about your site visit at our location on VAR2 We will be looking forward to your further association with us VAR3. Thank you Team Kanoujia City</option>

                            <option value="20">May this holi happiness overflow & there be lots of fun and frolic.Happy holi Best Regard, Team Kanoujia City</option>

                        </select>
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable2" style="display:none;">
                    <div class="form-group">
                      <label for="variable2" class="col-sm-3 control-label">VAR2</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable2" name="variables[variable2]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable3" style="display:none;">
                    <div class="form-group">
                      <label for="variable3" class="col-sm-3 control-label">VAR3</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable3" name="variables[variable3]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable4" style="display:none;">
                    <div class="form-group">
                      <label for="variable4" class="col-sm-3 control-label">VAR4</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable4" name="variables[variable4]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable5" style="display:none;">
                    <div class="form-group">
                      <label for="variable5" class="col-sm-3 control-label">VAR5</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable5" name="variables[variable5]">
                      </div>
                    </div>
                 </div>
                 <div class="col-sm-12 variable6" style="display:none;">
                    <div class="form-group">
                      <label for="variable6" class="col-sm-3 control-label">VAR6</label>
                      <div class="col-sm-8">
                        <input class="form-control" id="variable6" name="variables[variable6]">
                      </div>
                    </div>
                 </div>
                 <table class="table table-striped table-hover table-bordered">
                    <tr>
                      <th><input type="checkbox" id="checkAll" class="checkAll" for="checkAll"></th>
                      <th>Sl No.</th>
                      <th>Name</th>
                      <th>Mobile</th>
                      <th>Type</th>
                      <th>Created</th>
                    </tr>
                    <?php
                    $url = 'send_message.php?';

                    $limit = 500;
                    if(isset($_GET['page'])){
                        $page = $_GET['page'];
                    }else{
                        $page = 1;
                    }
                    $query = "select * from kc_contacts where status = '1' ";

                    if(isset($_GET['type']) && $_GET['type'] == "contacts"){
                      $query .= " and type = 'Contact'";
                      $url .= "type=".$_GET['type']."&";
                    }else if(isset($_GET['type']) && $_GET['type'] == "customers"){
                      $query .= " and type = 'Customer'";
                      $url .= "type=".$_GET['type']."&";
                    }else if(isset($_GET['type']) && $_GET['type'] == "employees"){
                      $query .= " and type = 'Employee'";
                      $url .= "type=".$_GET['type']."&";
                    }else if(isset($_GET['type']) && $_GET['type'] == "associate"){
                      $query .= " and type = 'Associate'";
                      $url .= "type=".$_GET['type']."&";
                    }

                    $total_records = mysqli_num_rows(mysqli_query($conn,$query));
                    $total_pages = ceil($total_records/$limit);
                    
                    if($page == 1){
                        $start = 0;
                    }else{
                        $start = ($page-1)*$limit;
                    }
                    
                    $query .= " limit $start,$limit";

                    $contacts = mysqli_query($conn,$query);
                    if(mysqli_num_rows($contacts) > 0){
                        $counter = $start+1;
                        while($contact = mysqli_fetch_assoc($contacts)){ ?>
                            <tr>
                                <td><input type="checkbox" name="contacts[<?php echo $contact['id']; ?>]" value="<?php echo $contact['mobile']; ?>" class="contact"></td>
                                <td><?php echo $counter; ?>.</td>
                                <td><?php echo $contact['name']; ?><input type="hidden" name="names[<?php echo $contact['id']; ?>]" value="<?php echo $contact['name']; ?>"></td>
                                <td><?php echo $contact['mobile']; ?></td>
                                <td>
                                  <?php if($contact['type'] == "Associate"){ ?>
                                    <label class="label label-info">Associate</label>
                                  <?php }else if($contact['type'] == "Customer"){ ?>
                                    <label class="label label-success">Customer</label>
                                  <?php }else if($contact['type'] == "Contact"){ ?>
                                      <label class="label label-danger">Contact</label>
                                  <?php }else { ?>
                                      <label class="label label-warning">Employee</label>
                                  <?php } ?>
                                </td>
                                <td><?php echo date("d M Y h:i A",strtotime($contact['created'])); ?></td>
                                
                            </tr>
                            <?php
                            $counter++;
                        } ?>
                        <tr>
                            <td colspan="6" align="center"><button class="btn btn-primary btn-sm">Send</button></td>
                        </tr>
                        <?php
                    }else{
                        ?>
                        <tr>
                            <td colspan="9" align="center"><h4 class="text-red">No Record Found</h4></td>
                        </tr>
                        <?php
                    }
                    ?>
                  </table>
              </form>
        </div><!-- /.box-body -->
				
				<?php if($total_pages > 1){ ?>
					<div class="box-footer clearfix">
					  <ul class="pagination pagination-sm no-margin pull-right">
					   
						<?php

            
							for($i = 1; $i <= $total_pages; $i++){
								?>
								 <li <?php if((isset($_GET['page']) && $i == $_GET['page']) || (!isset($_GET['page']) && $i == 1)){ ?>class="active"<?php } ?>><a href="<?php echo $url ?>page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
								<?php
							}
						?>
						
					  </ul>
					</div>
				<?php } ?>
				
              </div><!-- /.box -->
        </section> 
          
      </div><!-- /.content-wrapper -->    
      <?php require('../includes/footer.php'); ?>

      <?php require('../includes/control-sidebar.php'); ?>
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->
	
	<?php require('../includes/common-js.php'); ?>
	
    <script type="text/javascript">
	$(function(){
		$("#template").change(function(){
			
			if($(this).val() == '15'){
				$(".variable6").show();
			}else{
				$(".variable6").hide();
			}

			if($(this).val() == '14' || $(this).val() == '15'){
				$(".variable5").show();
			}else{
				$(".variable5").hide();
			}

			if($(this).val() == '14' || $(this).val() == '15' || $(this).val() == '16' || $(this).val() == '17'){
				$(".variable4").show();
			}else{
				$(".variable4").hide();
			}

			if($(this).val() == '14' || $(this).val() == '15' || $(this).val() == '16' || $(this).val() == '17' || $(this).val() == '19'){
				$(".variable3").show();
			}else{
				$(".variable3").hide();
			}

			if($(this).val() == '1' || $(this).val() == '5' || $(this).val() == '14' || $(this).val() == '15' || $(this).val() == '16' || $(this).val() == '17' || $(this).val() == '18' || $(this).val() == '19'){
				$(".variable2").show();
			}else{
				$(".variable2").hide();
			}

			<?php /*else if($(this).val() == '1' || $(this).val() == '5'){
				$(".variable2").show();
			}else{
				$(".variable2").find('input').val('');
				$(".variable2").hide();
			}*/ ?>
		});
    $("#send_message_frm").submit(function(e){
      if($("#template").val() == ""){
        alert("Please select a Message Template.");
        e.preventDefault();
      }else if($("#template").val() == "1" && $("#variable2").val() == ""){
        alert("Please Fill Festival Name.");
        e.preventDefault();
      }else if($(".contact:checked").length == 0){
        alert("Please select atleast one Contact.");
        e.preventDefault();
      }
    });
	});
	function iCheckClicked(elem){
		 var for_attr = $(elem).attr('for');
		 if(for_attr == "checkAll"){
			 if(!($(elem).is(":checked"))){
			 	$('.contact').iCheck('check');
			 }else{
				 $('.contact').iCheck('uncheck');
			 }
		 }
	}
	</script>
    
  </body>
</html>