<?php
	ob_start();
	session_start();

	require("../includes/host.php");
	require("../includes/kc_connection.php");
	require("../includes/common-functions.php");
	require("../includes/checkAuth.php");

	header("Content-Type: application/xls");    
	header("Content-Disposition: attachment; filename=report-".date('d-M-y').".xls");  
	header("Pragma: no-cache"); 
	header("Expires: 0");

	$query = "select * from kc_customer_blocks where status = '1' ";
	if(isset($_GET['search_project']) || isset($_GET['search_block']) || isset($_GET['search_block_no']) || (isset($_GET['search_block_no']) && $_GET['search_block_no']>0) || (isset($_GET['search_associate']) && (int) $_GET['search_associate'] > 0)){  
		//echo "<pre>"; print_r($_GET); die;
		if(isset($_GET['search_block']) && $_GET['search_block']!=''){
			$query .= " and block_id = '".$_GET['search_block']."'";
		}

		if(isset($_GET['search_block_no']) && $_GET['search_block_no']!=''){
			$query .= " and block_number_id = '".$_GET['search_block_no']."'";
		}

		if(isset($_GET['search_project']) && $_GET['search_project']>0){
			$query .= " and block_id IN (select id from kc_blocks where status = '1' and project_id = '".$_GET['search_project']."' )";
		}

		if(isset($_GET['search_associate']) && (int) $_GET['search_associate'] > 0){
			$associate_id = (int) $_GET['search_associate'];
			$query .= " and associate = '$associate_id'";
		}

		$query .= " order by registry_date desc";
		$customers = mysqli_query($conn,$query);
		$search = true;
	}

	if($search && mysqli_num_rows($customers) > 0){

		echo '<table border="1">';
		//make the column headers what you want in whatever order you want
		echo '<tr><th>Sr.</th><th>Project</th><th>Block</th><th>Plot No.</th><th>Customer Name</th><th>Associate</th><th>Rate</th><th>Area</th><th>Amount</th><th>Received Amount</th><th>Pending Amount</th></tr>';
		//loop the query data to the table in same order as the headers
		$counter = 1;
		$total_debited_amt = $total_credited_amt = $total_pending_amt = $total_debited = $total_credited = $pending_amount = 0;
		while($customer = mysqli_fetch_assoc($customers)){
			$total_debited_amt += $total_debited = totalDebited($conn,$customer['customer_id'],$customer['block_id'],$customer['block_number_id']);
			$total_credited_amt += $total_credited = totalCredited($conn,$customer['customer_id'],$customer['block_id'],$customer['block_number_id']);
			$block_details = mysqli_fetch_assoc(mysqli_query($conn,"select area from kc_block_numbers where block_id = '".$customer['block_id']."' and id = '".$customer['block_number_id']."' and status = '1' "));
			$total_pending_amt += $pending_amount = ($total_credited - $total_debited);

		    echo "<tr><td>".$counter."</td><td>".blockProjectName($conn,$customer['block_id'])."</td><td>".blockName($conn,$customer['block_id'])."</td><td>".blockNumberName($conn,$customer['block_number_id'])."</td><td>".customerName($conn,$customer['customer_id']).' ('.customerID($customer['customer_id']).')'."</td><td>".associateName($conn,$customer['associate'])."</td><td>".number_format($customer['rate_per_sqft'],2)."</td><td>".$block_details['area']."</td><td>".number_format($total_credited,2)."</td><td>".number_format($total_debited,2)."</td><td>".number_format($pending_amount,2)."</td></tr>";
		    $counter++;
		}
		echo "<tr><td colspan='8' align='right'>Total</td><td>".number_format($total_credited_amt,2)."</td><td>".number_format($total_debited_amt,2)."</td><td>".number_format($total_pending_amt,2)."</td></tr></table>";
	}
?>